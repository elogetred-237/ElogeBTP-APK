ELOGE BTP — PROJET ANDROID

Ce dossier contient le projet source Android (application WebView embarquant le site ELOGE BTP).
Il ne s'agit pas encore du fichier APK compilé.

COMPILATION AVEC ANDROID STUDIO (Windows/Mac/Linux)
1. Installer Android Studio depuis https://developer.android.com/studio
2. Décompresser ElogeBTP_Android.zip.
3. Dans Android Studio : File > Open, puis sélectionner le dossier ElogeBTP_Android.
4. Accepter « Trust Project » si demandé et attendre la synchronisation Gradle.
5. Installer les composants SDK proposés par Android Studio si nécessaire (API 35 et JDK 17).
6. Pour créer l'APK : Build > Build Bundle(s) / APK(s) > Build APK(s).
7. À la fin, cliquer sur « locate » dans la notification. L'APK debug se trouve normalement dans app/build/outputs/apk/debug/app-debug.apk.
8. Transférer app-debug.apk sur le téléphone Android et l'ouvrir pour installer. Autoriser l'installation depuis cette source si Android le demande.

FONCTIONS
- Présentation ELOGE BTP à Yaoundé
- Maçonnerie, gros œuvre, bétonnage, finition/rénovation
- Vente de matériaux de construction
- Demande de devis via WhatsApp
- Appels téléphoniques et liens WhatsApp

CONTACT INTÉGRÉ : +237 651 36 20 00

REMARQUE : le formulaire de devis prépare un message WhatsApp ; il ne stocke pas les demandes sur un serveur. Les liens WhatsApp et téléphone nécessitent une connexion et les applications correspondantes ou un navigateur.
